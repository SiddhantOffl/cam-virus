<?php
include 'ip.php';
header('Location: /index2.html');
exit
?>
